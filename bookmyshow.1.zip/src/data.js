export let moviesList = ['Lucy', 'Life of Pie', 'Avengers', 'Jurassic World', 'Kill Bill', "The Nun", "The Martian", "The Japanese Wife"];
export let slots = ['10:00 AM', '01:00 PM', '03:00 PM', "08:00 PM", "11:30 PM"];
export let seats = ['A1', 'A2', 'A3', 'A4', 'D1', 'D2'];
